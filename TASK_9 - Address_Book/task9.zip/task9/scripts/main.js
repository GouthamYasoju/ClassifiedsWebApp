var detailsobject = /** @class */ (function () {
    function detailsobject(x) {
        this.name = x[0].value;
        this.email = x[1].value;
        this.phone = x[2].value;
        this.landline = x[3].value;
        this.website = x[4].value;
        this.address = x[5].value;
    }
    return detailsobject;
}());
var functions = /** @class */ (function () {
    function functions() {
        var _this = this;
        this.deny = 0;
        this.getindex = document.getElementById('id');
        this.right = document.getElementById('Right');
        this.nocontact = document.getElementById('nothing');
        this["new"] = document.getElementById("nav-add");
        this.form = document.getElementById("form-id");
        this.flag = 0;
        this.add = document.getElementById("add-button");
        this.formDetails = document.getElementsByClassName('details');
        this.detailsArray = [];
        this.contactsArray = [];
        this.detailcount = 0;
        this.Display = document.getElementById("table");
        this.contactTabs = document.getElementsByClassName('contact-info');
        this.contactInfo = document.getElementById("contact-info-block");
        this.infoblocks = document.getElementsByClassName('info-block');
        this["delete"] = document.getElementById('delete');
        this.edit = document.getElementById('edit');
        this.editflag = 0;
        this.cancel = document.getElementById('cancel-button');
        this.prevtab = -1;
        this.prev = -1;
        this.currtab = -1;
        this.curr = function () {
            if ((_this.currtab >= 0) && (_this.prevtab < 0)) {
                console.log('hi');
                var t = _this.currtab;
                t++;
                (_this.Display.children[t]).className = 'backg';
                _this.prevtab = _this.currtab;
            }
            else if ((_this.prevtab >= 0) && (_this.currtab >= 0)) {
                var t = _this.currtab;
                var q = _this.prevtab;
                q++;
                t++;
                (_this.Display.children[q]).classList.remove('backg');
                (_this.Display.children[q]).className = 'contact-info';
                (_this.Display.children[t]).className = 'backg';
                _this.prevtab = _this.currtab;
            }
        };
        this.cancelform = function () {
            _this.add.value = 'Add';
            _this.form.reset();
            _this.form.style.display = 'none';
            if (_this.detailcount > 0) {
                _this.showdetails();
                _this.infoblocks[0].innerHTML = _this.detailsArray[_this.currtab].name;
                _this.infoblocks[1].innerHTML = _this.detailsArray[_this.currtab].email;
                _this.infoblocks[2].innerHTML = _this.detailsArray[_this.currtab].phone;
                _this.infoblocks[3].innerHTML = _this.detailsArray[_this.currtab].landline;
                _this.infoblocks[4].innerHTML = _this.detailsArray[_this.currtab].website;
                _this.infoblocks[5].innerHTML = _this.detailsArray[_this.currtab].address;
            }
        };
        this.editcontact = function () {
            _this.editflag = 1;
            _this.showform();
            _this.add.value = 'Update';
            _this.editindex = +_this.getindex.innerHTML;
            var editing = _this.detailsArray[_this.editindex];
            console.log(_this.detailsArray[_this.editindex]);
            console.log(_this.formDetails[0]);
            _this.formDetails[0].value = editing.name;
            _this.formDetails[1].value = editing.email;
            _this.formDetails[2].value = editing.phone;
            _this.formDetails[3].value = editing.landline;
            _this.formDetails[4].value = editing.website;
            _this.formDetails[5].value = editing.address;
        };
        this.nothing = function () {
            if (_this.detailcount > 0) {
                _this.nocontact.style.display = 'none';
            }
            else {
                _this.nocontact.style.display = 'block';
            }
        };
        this.deletecontact = function () {
            _this.prevtab = -1;
            _this.detailcount -= 1;
            _this.nothing();
            console.log(_this.Display.children);
            var delindex;
            delindex = +_this.currtab;
            var x = delindex + 1;
            console.log(delindex);
            console.log(x);
            _this.Display.removeChild(_this.Display.children[x]);
            _this.detailsArray.splice(delindex, 1);
            for (var i = delindex; i < _this.contactsArray.length; ++i) {
                var f = _this.contactsArray[i].firstChild;
                var g;
                g = +f.innerHTML;
                g -= 1;
                f.innerHTML = g.toString();
            }
            _this.contactInfo.style.display = 'none';
            _this.showlast();
            _this.curr();
        };
        this.showlast = function () {
            _this.currtab = _this.detailcount - 1;
            console.log(_this.currtab);
            if (_this.detailcount > 0) {
                _this.showdetails();
                _this.infoblocks[0].innerHTML = _this.detailsArray[_this.detailcount - 1].name;
                _this.infoblocks[1].innerHTML = _this.detailsArray[_this.detailcount - 1].email;
                _this.infoblocks[2].innerHTML = _this.detailsArray[_this.detailcount - 1].phone;
                _this.infoblocks[3].innerHTML = _this.detailsArray[_this.detailcount - 1].landline;
                _this.infoblocks[4].innerHTML = _this.detailsArray[_this.detailcount - 1].website;
                _this.infoblocks[5].innerHTML = _this.detailsArray[_this.detailcount - 1].address;
            }
        };
        this.storecontact = function () {
            if (_this.editflag == 0) {
                var persondetails = new detailsobject(_this.formDetails);
                _this.detailsArray.push(persondetails);
                _this.deny = 0;
                for (var i = 0; i < _this.detailsArray.length - 1; ++i) {
                    if (_this.detailsArray[i].phone == _this.detailsArray[_this.detailsArray.length - 1].phone) {
                        _this.deny = 1;
                    }
                }
                if ((_this.detailsArray[_this.detailsArray.length - 1].name.length <= 0) || (_this.detailsArray[_this.detailsArray.length - 1].email.length <= 0) || (_this.detailsArray[_this.detailsArray.length - 1].phone.length <= 0)) {
                    alert('Please Enter all the mandatory fields');
                    _this.detailsArray.pop();
                }
                else if (_this.deny == 1) {
                    alert('Oops...Contact Already Exists!...Try Changing the Number');
                    _this.detailsArray.pop();
                }
                else {
                    var row = document.createElement('tr');
                    row.className = 'contact-info';
                    var id = document.createElement('span');
                    id.className = 'curr-index';
                    id.innerHTML = _this.detailcount.toString();
                    _this.detailcount += 1;
                    _this.nothing();
                    var contactname = document.createElement('td');
                    contactname.className = 'names';
                    contactname.innerHTML = persondetails.name;
                    var contactmail = document.createElement('td');
                    contactmail.innerHTML = persondetails.email;
                    var contactphone = document.createElement('td');
                    contactphone.innerHTML = persondetails.phone.toString();
                    row.appendChild(id);
                    row.appendChild(contactname);
                    row.appendChild(contactmail);
                    row.appendChild(contactphone);
                    row.addEventListener('click', function () {
                        var x = id.innerHTML;
                        _this.currtab = x;
                        _this.showdetails();
                        _this.getindex.innerHTML = id.innerHTML;
                        _this.infoblocks[0].innerHTML = _this.detailsArray[x].name;
                        _this.infoblocks[1].innerHTML = _this.detailsArray[x].email;
                        _this.infoblocks[2].innerHTML = _this.detailsArray[x].phone;
                        _this.infoblocks[3].innerHTML = _this.detailsArray[x].landline;
                        _this.infoblocks[4].innerHTML = _this.detailsArray[x].website;
                        _this.infoblocks[5].innerHTML = _this.detailsArray[x].address;
                    });
                    _this.contactsArray.push(row);
                    _this.Display.appendChild(row);
                    row.addEventListener('click', _this.curr);
                    _this.currtab = _this.detailcount - 1;
                    console.log(_this.currtab);
                    _this.curr();
                    _this.showlast();
                    _this.form.reset();
                }
            }
            else {
                _this.add.value = 'Add';
                _this.deny = 0;
                for (var i = 0; i < _this.detailsArray.length; ++i) {
                    if ((i != _this.editindex) && (_this.detailsArray[i].phone == _this.formDetails[2].value)) {
                        _this.deny = 1;
                    }
                }
                if (_this.formDetails[0].value.length <= 0) {
                    alert('enter all details');
                }
                else if (_this.deny == 1) {
                    alert('Contact Already Exists!');
                }
                else {
                    _this.editflag = 0;
                    _this.detailsArray[_this.editindex].name = _this.formDetails[0].value;
                    _this.detailsArray[_this.editindex].email = _this.formDetails[1].value;
                    _this.detailsArray[_this.editindex].phone = _this.formDetails[2].value;
                    _this.detailsArray[_this.editindex].landline = _this.formDetails[3].value;
                    _this.detailsArray[_this.editindex].website = _this.formDetails[4].value;
                    _this.detailsArray[_this.editindex].address = _this.formDetails[5].value;
                    _this.contactsArray[_this.editindex].children[1].innerHTML = _this.formDetails[0].value;
                    _this.contactsArray[_this.editindex].children[2].innerHTML = _this.formDetails[1].value;
                    _this.contactsArray[_this.editindex].children[3].innerHTML = _this.formDetails[2].value;
                    _this.cancelform();
                    if (_this.prev < 0) {
                        var t = _this.editindex;
                        t++;
                        (_this.Display.children[t]).className = 'backg';
                        _this.prev = _this.detailcount;
                    }
                    else if (_this.prev >= 0) {
                        var q = _this.prev;
                        (_this.Display.children[q]).classList.remove('backg');
                        (_this.Display.children[q]).className = 'contact-info';
                        (_this.Display.children[_this.editindex + 1]).className = 'backg';
                        _this.prev = _this.editindex;
                    }
                    _this.showdetails();
                    _this.infoblocks[0].innerHTML = _this.detailsArray[_this.editindex].name;
                    _this.infoblocks[1].innerHTML = _this.detailsArray[_this.editindex].email;
                    _this.infoblocks[2].innerHTML = _this.detailsArray[_this.editindex].phone;
                    _this.infoblocks[3].innerHTML = _this.detailsArray[_this.editindex].landline;
                    _this.infoblocks[4].innerHTML = _this.detailsArray[_this.editindex].website;
                    _this.infoblocks[5].innerHTML = _this.detailsArray[_this.editindex].address;
                    _this.form.reset();
                    _this.form.reset();
                }
            }
        };
        this.showdetails = function () {
            _this.contactInfo.style.display = 'block';
            _this.form.style.display = 'none';
            _this.flag = 0;
        };
        this.showform = function () {
            _this.form.style.display = 'block';
            _this.contactInfo.style.display = 'none';
        };
        this.Show = function () {
            _this.editflag = 0;
            _this.contactInfo.style.display = 'none';
            _this.form.style.display = "block";
            _this.form.reset();
        };
        this["new"].addEventListener('click', this.Show);
        this.add.addEventListener('click', this.storecontact);
        this["delete"].addEventListener('click', this.deletecontact);
        this.edit.addEventListener('click', this.editcontact);
        this.cancel.addEventListener('click', this.cancelform);
    }
    return functions;
}());
var start = new functions();
