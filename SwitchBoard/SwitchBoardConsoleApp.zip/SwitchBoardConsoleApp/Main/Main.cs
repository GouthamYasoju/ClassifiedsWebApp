﻿namespace PLAY_GROUND
{
    public class Program
    {

        public static void Main(string[] args)
        {
            new Controller();

        }
    }
}
